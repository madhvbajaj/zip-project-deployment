package com.madhv.servlets;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class EmployeeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idParam = request.getParameter("id");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<table border='1'><tr><th>EmpID</th><th>Name</th><th>Salary</th></tr>");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "Madhv}001");
            Statement stmt = con.createStatement();
            ResultSet rs;
            if(idParam != null && !idParam.isEmpty()) {
                rs = stmt.executeQuery("SELECT * FROM Employee WHERE EmpID=" + idParam);
            } else {
                rs = stmt.executeQuery("SELECT * FROM Employee");
            }
            while(rs.next()) {
                out.println("<tr><td>"+rs.getInt("EmpID")+"</td><td>"+rs.getString("Name")+"</td><td>"+rs.getDouble("Salary")+"</td></tr>");
            }
            con.close();
        } catch(Exception e) {
            out.println("<tr><td colspan='3'>Error: " + e.getMessage() + "</td></tr>");
        }
        out.println("</table>");
    }
}