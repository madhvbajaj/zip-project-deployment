package com.madhv.servlets;

import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AttendanceServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int studentId = Integer.parseInt(request.getParameter("studentId"));
        String date = request.getParameter("date");
        String status = request.getParameter("status");

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/testdb", "root", "Madhv}001");
            PreparedStatement ps = con.prepareStatement("INSERT INTO Attendance(StudentID, AttendanceDate, Status) VALUES(?,?,?)");
            ps.setInt(1, studentId);
            ps.setDate(2, Date.valueOf(date));
            ps.setString(3, status);
            ps.executeUpdate();
            con.close();
            out.println("<h2>Attendance Recorded Successfully!</h2>");
        } catch(Exception e) {
            out.println("<h2>Error: " + e.getMessage() + "</h2>");
        }
    }
}